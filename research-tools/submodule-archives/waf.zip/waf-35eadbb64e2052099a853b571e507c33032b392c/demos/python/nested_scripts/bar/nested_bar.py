"""
Nested file in bar/
"""
