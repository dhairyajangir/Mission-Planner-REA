public class JavaTestA {
}
