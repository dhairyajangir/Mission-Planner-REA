int u = 48;
