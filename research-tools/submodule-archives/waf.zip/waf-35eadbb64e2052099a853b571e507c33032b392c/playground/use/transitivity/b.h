extern void b();

